set(groot,'defaultLineMarkerSize',7)
format long g
%% Task 4
run run_task4.m

%% Task 5
run run_task5.m

%% Task 6
run run_task6.m

%% Task 7
run run_task7.m




