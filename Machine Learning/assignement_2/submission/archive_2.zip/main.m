clear all
clc
%% T1 and T2
run run_task_t12.m

%% e1
run run_task_e1.m

%% e2
run run_task_e2.m

%% e3 
run run_task_e3.m

%% e4 and e5 
run run_task_e45.m %This one may take some time to run

%% e6 and e7
run run_task_e67.m 