function Y = relu_forward(X)
    Y = max(X,0);
end