run run_exercise_6.m
run run_exercise_7.m