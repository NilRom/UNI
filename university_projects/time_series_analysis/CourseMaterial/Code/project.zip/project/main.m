%%
clear all
clc
addpath Code/project
addpath Code/project/projDatafiles
%%
run Code/project/task_a_clean.m

%%
run Code/project/task_b.m